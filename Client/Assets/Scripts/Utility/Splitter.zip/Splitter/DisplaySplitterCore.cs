using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

/// 显示分离器：核心
public interface IDisplaySplitterCore
{
    /// 必回收时的条件 ||
    /// 1、对象池 Get 出来的 Core
    /// 2、订阅了 标记为 回收 的 list
    void Release();
    
    /// 订阅器，list 来自对象池，且需要 Release 时触发 回收，须标记
    IDisplaySplitterCore Subscribe(int key, List<GameObject> items, bool allowRelease = false);
    
    void DisplayUnique(int key);
    /// 即时回收，keys 来自非对象池，勿标记回收
    void DisplaySet(List<int> keys, bool allowRelease = false);
    /// 当 订阅的 key 为 flags 时，可使用
    void DisplayFlags(int keyFlags);
}

/// 显示分离器：核心 Mono 形态 额外扩展
public interface IDisplaySplitterCoreMonoExtensions
{
    /// 自动回收
    void Release();
    
    /// 自动订阅
    void Subscribe((Dictionary<int, List<GameObject>> items, HashSet<int> allowReleases) model);
}

/// 显示分离器：核心 Mono 形态 基类
public abstract class DisplaySplitterMonoBase : MonoBehaviour
{
    [SerializeField] protected bool flags;
    public bool Flags => flags;
    public abstract DisplaySplitterCore Core { get; }
}

public class DisplaySplitterCore: IDisplaySplitterCore, IDisplaySplitterCoreMonoExtensions
{
    private bool allowReleaseSelf;
    private Dictionary<int, List<GameObject>> _items;
    private Dictionary<int, List<GameObject>> items
    {
        get
        {
            if (_items == null)
            {
                if (allowReleaseSelf) _items = DictionaryPool<int, List<GameObject>>.Get();
                else _items = new Dictionary<int, List<GameObject>>();
            }
            return _items;
        }
    }
    private HashSet<int> _allowReleases;
    private HashSet<int> allowReleases => _allowReleases ??= HashSetPool<int>.Get();
    
    public static DisplaySplitterCore Get()
    {
        DisplaySplitterCore core = GenericPool<DisplaySplitterCore>.Get();
        core.allowReleaseSelf = true;
        return core;
    }
    public DisplaySplitterCore(): this(false) { }
    private DisplaySplitterCore(bool allowReleaseSelf)
    {
        this.allowReleaseSelf = allowReleaseSelf;
    }

    void IDisplaySplitterCore.Release() => Release();
    void IDisplaySplitterCoreMonoExtensions.Release() => Release();
    private void Release()
    {
        if (_items != null)
        {
            if (_allowReleases != null)
            {
                foreach (var pair in _items)
                {
                    if (!_allowReleases.Contains(pair.Key))
                    {
                        continue;
                    }
                    ListPool<GameObject>.Release(pair.Value);
                }
                HashSetPool<int>.Release(_allowReleases);
                _allowReleases = null;
            }
            if (allowReleaseSelf)
            {
                DictionaryPool<int, List<GameObject>>.Release(_items);
                _items = null;
            }
        }
        if (allowReleaseSelf) GenericPool<DisplaySplitterCore>.Release(this);
    }
    
    IDisplaySplitterCore IDisplaySplitterCore.Subscribe(int key, List<GameObject> items, bool allowRelease)
    {
        this.items.Add(key, items);
        if (allowRelease) allowReleases.Add(key);
        return this;
    }
    void IDisplaySplitterCoreMonoExtensions.Subscribe((Dictionary<int, List<GameObject>> items, HashSet<int> allowReleases) model)
    {
        (_items, _allowReleases) = model;
    }

    public void DisplayUnique(int key)
    {
        foreach (var pair in items)
        {
            bool isDisplay = pair.Key == key;
            foreach (var item in pair.Value)
            {
                item.SetActive(isDisplay);
            }
        }
    }

    public void DisplaySet(List<int> keys, bool allowRelease = false)
    {
        foreach (var pair in items)
        {
            bool isDisplay = keys.Contains(pair.Key);
            foreach (var item in pair.Value)
            {
                item.SetActive(isDisplay);
            }
        }
        if (allowRelease) ListPool<int>.Release(keys);
    }

    public void DisplayFlags(int keyFlags)
    {
        foreach (var pair in items)
        {
            bool isDisplay = (keyFlags & pair.Key) == pair.Key;
            foreach (var item in pair.Value)
            {
                item.SetActive(isDisplay);
            }
        }
    }
}