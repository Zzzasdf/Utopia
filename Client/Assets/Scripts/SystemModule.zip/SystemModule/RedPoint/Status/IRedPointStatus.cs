// using ReddotModule;
//
// public interface IReddotStatus
// {
//     void InitRedTip(EReddot eReddot, ReddotTree reddotTree);
//     EReddot Linker(params EReddot[] childRedTips);
//
//     int Count(params int[] indexs);
//     bool Update(params int[] indexs);
// }