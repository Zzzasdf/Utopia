using Unity.Collections;
using UnityEngine;
using UnityEngine.Serialization;

namespace RedPointModule
{
    public interface IRedPointComponent
    {
        void Update(bool status, params int[] indexs);
    }

    public class RedPointComponent : MonoBehaviour, IRedPointComponent
    {
        [SerializeField] [ReadOnly] private ERedPoint eRedPoint;
        private int[] indexs;

        private void Awake()
        {
            eRedPoint.AddComponent(this);
        }

        public void UpdateParam(int[] indexs)
        {
            this.indexs = indexs;
        }

        void IRedPointComponent.Update(bool status, params int[] indexs)
        {
            if (!this.indexs.Equals(indexs))
            {
                return;
            }
            gameObject.SetActive(status);
        }
    }
}