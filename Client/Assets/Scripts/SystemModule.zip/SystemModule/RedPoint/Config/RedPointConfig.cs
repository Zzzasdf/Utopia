using System.Collections.Generic;

namespace RedPointModule
{
    public partial class RedPointConfig
    {
        /// 模型列表
        private partial List<ERedPoint> ModelList() => new()
        {
            TestFunc2(),
        };

        private ERedPoint TestFunc2() =>
            ERedPoint.TestIcon.Linker(
                ERedPoint.TestTab1.Linker(
                    ERedPoint.TestDataList.Linker(
                        ERedPoint.TestDataUnit.BindNodeLayer1<Layer1>(Layer1Condition, Layer1Count).Linker(
                            ERedPoint.TestDataUnitChild.BindNodeLayer2<Layer2>(Layer2Condition, Layer2Count))),
                    ERedPoint.TestTab2),
                ERedPoint.TestTab2);
        
        public int Layer1Count()
        {
            return 10;
        }

        public bool Layer1Condition(int layer1Index)
        {
            return false;
        }

        public int Layer2Count(int layer1Index)
        {
            return 10;
        }
        public bool Layer2Condition(int layer1Index, int layer2Index)
        {
            return false;
        }
    }
}