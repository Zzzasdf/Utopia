using System;
using System.Collections.Generic;
using UnityEditor.Playables;

namespace RedPointModule
{
    public interface IRedPointConfig
    {
        /// 连接器
        ERedPoint Linker(ERedPoint parentERedPoint, params ERedPoint[] childRedTips);
        /// 绑定节点 => Common
        ERedPoint BindNode(ERedPoint eRedPoint);
        /// 绑定节点 => Common + Condition
        ERedPoint BindNode(ERedPoint eRedPoint, ReddotConditionByCommonDelegate reddotConditionByCommonDelegate);
        /// 绑定节点 => Layer1
        ERedPoint BindNodeLayer1<T>(ERedPoint eRedPoint) where T : IReddotNodeCollectionsLayer1;
        /// 绑定节点 => Layer1 + Condition
        ERedPoint BindNodeLayer1<T>(ERedPoint eRedPoint, ReddotConditionByCollectionsLayer1Delegate reddotConditionByCollectionsLayer1Delegate, ReddotCountByCollectionsLayer1Delegate reddotCountByCollectionsLayer1Delegate) where T : IReddotNodeCollectionsLayer1;
        /// 绑定节点 => Layer2
        ERedPoint BindNodeLayer2<T>(ERedPoint eRedPoint) where T: IReddotNodeCollectionsLayer2;
        /// 绑定节点 => Layer2 + Condition
        ERedPoint BindNodeLayer2<T>(ERedPoint eRedPoint, ReddotConditionByCollectionsLayer2Delegate reddotConditionByCollectionsLayer2Delegate, ReddotCountByCollectionsLayer2Delegate reddotCountByCollectionsLayer2Delegate) where T : IReddotNodeCollectionsLayer2;
    }

    public partial class RedPointConfig: IRedPointConfig
    {
        private Dictionary<ERedPoint, IRedPointNode> reddotNodeMap = new Dictionary<ERedPoint, IRedPointNode>();
        
        public RedPointConfig()
        {
            List<ERedPoint> detectionList = ModelList();
            foreach (var redTip in detectionList)
            {
                if (!ClosedLoopInspection(redTip))
                {
                    continue;
                }
                return;
            }
        }

        /// 模型列表
        private partial List<ERedPoint> ModelList();

        /// 闭环检测 (快慢指针)
        private bool ClosedLoopInspection(ERedPoint eRedPoint)
        {
            // TODO ZZZ => 检测，抛出异常点
            return false;
        }

        ERedPoint IRedPointConfig.BindNode(ERedPoint eRedPoint)
        {
            throw new NotImplementedException();
        }

        ERedPoint IRedPointConfig.BindNode(ERedPoint eRedPoint, ReddotConditionByCommonDelegate reddotConditionByCommonDelegate)
        {
            throw new NotImplementedException();
        }

        ERedPoint IRedPointConfig.BindNodeLayer1<T>(ERedPoint eRedPoint)
        {
            throw new NotImplementedException();
        }

        ERedPoint IRedPointConfig.BindNodeLayer1<T>(ERedPoint eRedPoint, ReddotConditionByCollectionsLayer1Delegate reddotConditionByCollectionsLayer1Delegate, ReddotCountByCollectionsLayer1Delegate reddotCountByCollectionsLayer1Delegate)
        {
            throw new NotImplementedException();
        }

        ERedPoint IRedPointConfig.BindNodeLayer2<T>(ERedPoint eRedPoint)
        {
            throw new NotImplementedException();
        }

        ERedPoint IRedPointConfig.BindNodeLayer2<T>(ERedPoint eRedPoint, ReddotConditionByCollectionsLayer2Delegate reddotConditionByCollectionsLayer2Delegate, ReddotCountByCollectionsLayer2Delegate reddotCountByCollectionsLayer2Delegate)
        {
            throw new NotImplementedException();
        }

        ERedPoint IRedPointConfig.Linker(ERedPoint parentERedPoint, params ERedPoint[] childRedTips)
        {
            throw new NotImplementedException();
        }
    }
}