namespace RedPointModule
{
    public interface IRedPointTreeManager
    {
        IRedPointConfig RedPointConfig { get; }
        IRedPointTree RedPointTree { get; }
    }
    
    public class RedPointTreeManager : IManager, IRedPointTreeManager
    {
        IRedPointConfig IRedPointTreeManager.RedPointConfig => RedPointConfig;
        IRedPointTree IRedPointTreeManager.RedPointTree => RedPointTree;
        private IRedPointConfig RedPointConfig { get; }
        private IRedPointTree RedPointTree { get; }

        public RedPointTreeManager()
        {
            RedPointConfig = new RedPointConfig();
            RedPointTree = new RedPointTree(RedPointConfig);
        }

        void IManager.Clear()
        {
        }
    }
}
