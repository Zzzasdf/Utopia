using System.Collections.Generic;

namespace RedPointModule
{
    public delegate bool ReddotConditionByCollectionsLayer1Delegate(int layer1Index);
    public delegate int ReddotCountByCollectionsLayer1Delegate();
    public interface IReddotNodeCollectionsLayer1
    {
        
    }
    public class Layer1 : IRedPointNode, IReddotNodeCollectionsLayer1
    {
        private ERedPoint current;
        private Dictionary<ERedPoint, IReddotNodeCommon> parents;
        
        
        private IRedPointNode redPointNodeImplementation;

        void IRedPointNode.SetReddot(ERedPoint eRedPoint)
        {
            throw new System.NotImplementedException();
        }

        ERedPoint IRedPointNode.Linker(params ERedPoint[] childrenReddots)
        {
            throw new System.NotImplementedException();
        }

        void IRedPointNode.AddParent(ERedPoint eRedPoint, IRedPointNode redPointNode)
        {
            throw new System.NotImplementedException();
        }

        void IRedPointNode.AddChild(ERedPoint eRedPoint, IRedPointNode redPointNode)
        {
            throw new System.NotImplementedException();
        }

        void IRedPointNode.AddComponent(IRedPointComponent redPointComponent)
        {
            throw new System.NotImplementedException();
        }

        void IRedPointNode.Update()
        {
            throw new System.NotImplementedException();
        }
    }
}
