using System.Collections.Generic;

namespace RedPointModule
{
    public delegate bool ReddotConditionByCollectionsLayer2Delegate(int layer1Index, int layer2Index);
    public delegate int ReddotCountByCollectionsLayer2Delegate(int layer1Index);
    public interface IReddotNodeCollectionsLayer2
    {
        
    }
    public class Layer2 : IRedPointNode, IReddotNodeCollectionsLayer2
    {
        private ERedPoint current;
        private Dictionary<ERedPoint, IReddotNodeCollectionsLayer1> parents;

        
        void IRedPointNode.SetReddot(ERedPoint eRedPoint)
        {
            throw new System.NotImplementedException();
        }

        ERedPoint IRedPointNode.Linker(params ERedPoint[] childrenReddots)
        {
            throw new System.NotImplementedException();
        }

        void IRedPointNode.AddParent(ERedPoint eRedPoint, IRedPointNode redPointNode)
        {
            throw new System.NotImplementedException();
        }

        void IRedPointNode.AddChild(ERedPoint eRedPoint, IRedPointNode redPointNode)
        {
            throw new System.NotImplementedException();
        }

        void IRedPointNode.AddComponent(IRedPointComponent redPointComponent)
        {
            throw new System.NotImplementedException();
        }

        void IRedPointNode.Update()
        {
            throw new System.NotImplementedException();
        }
    }
}
