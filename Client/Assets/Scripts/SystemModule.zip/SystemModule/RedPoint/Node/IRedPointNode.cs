using RedPointModule;

public interface IRedPointNode
{
    void SetReddot(ERedPoint eRedPoint);
    ERedPoint Linker(params ERedPoint[] childrenReddots);
    
    void AddParent(ERedPoint eRedPoint, IRedPointNode redPointNode);
    void AddChild(ERedPoint eRedPoint, IRedPointNode redPointNode);

    void AddComponent(IRedPointComponent redPointComponent);
    void Update();
}