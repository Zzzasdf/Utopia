using System.Collections.Generic;
using UnityEngine;

namespace RedPointModule
{
    public delegate bool ReddotConditionByCommonDelegate();
    public interface IReddotNodeCommon
    {
        
    }
    
    public class Common: IRedPointNode, IReddotNodeCommon
    {
        private ERedPoint current;
        private Dictionary<ERedPoint, IRedPointNode> parents;
        private Dictionary<ERedPoint, IRedPointNode> children;
        
        private LinkedList<IRedPointComponent> components;

        public Common()
        {
            
        }
        public Common(ERedPoint eRedPoint)
        {
            current = eRedPoint;
        }
        void IRedPointNode.SetReddot(ERedPoint eRedPoint)
        {
            current = eRedPoint;
        }

        ERedPoint IRedPointNode.Linker(params ERedPoint[] childrenReddots)
        {
            throw new System.NotImplementedException();
        }

        void IRedPointNode.AddParent(ERedPoint eRedPoint, IRedPointNode redPointNode)
        {
            this.parents ??= new Dictionary<ERedPoint, IRedPointNode>();
            if (!parents.TryAdd(eRedPoint, redPointNode))
            {
                Debug.LogError($"已存在该节点 => { eRedPoint } ");
            }
        }

        void IRedPointNode.AddChild(ERedPoint eRedPoint, IRedPointNode redPointNode)
        {
            this.children ??= new Dictionary<ERedPoint, IRedPointNode>();
            if (!children.TryAdd(eRedPoint, redPointNode))
            {
                Debug.LogError($"已存在该节点 => { eRedPoint }");
            }
        }

        public void AddComponent(IRedPointComponent redPointComponent)
        {
            components ??= new LinkedList<IRedPointComponent>();
            if (components.Contains(redPointComponent))
            {
                return;
            }
            components.AddLast(redPointComponent);
        }

        void IRedPointNode.Update()
        {
            
        }

        private void UpdateChildren(params int[] indexs)
        {
            // if (children == null || children.Count == 0)
            // {
            //     return;
            // }
            // List<int> childIndexList = new List<int>();
            // childIndexList.AddRange(indexs);
            // childIndexList.Add(-1);
            // foreach (var child in children)
            // {
            //     IReddotStatus childStatus = child.Value.GetStatus();
            //     for (int i = 0, count = childStatus.Count(indexs); i < count; i++)
            //     {
            //         childIndexList[indexs.Length] = i;
            //         int[] childIndexs = childIndexList.ToArray();
            //         child.Value.Update(childIndexs);   
            //     }
            // }
        }

        private void UpdateCurrent(params int[] indexs)
        {
            
        }

        private void UpdateParents(params int[] indexs)
        {
            
        }
    }
}
