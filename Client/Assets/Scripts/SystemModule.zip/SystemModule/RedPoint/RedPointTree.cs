using System;
using System.Collections.Generic;

namespace RedPointModule
{
    public interface IRedPointTree
    {
        /// 添加组件
        void AddComponent(ERedPoint current, IRedPointComponent redPointComponent);
        /// 通用更新
        void Update(ERedPoint current);
        // /// 通用更新（性能较差，安全性低）
        // void Update(EReddot current, params int[] indexs);
        // /// 更新入口 => Common
        // void UpdateCommon<T>(EReddot current) where T : IReddotNodeCommon;
        // /// 更新入口 => Collections
        // void UpdateCollections<T>(EReddot current) where T : IReddotNodeCollections;
        // /// 更新入口 => Layer1
        // void UpdateLayer1<T>(EReddot current) where T : IReddotNodeCollectionsLayer1;
        // /// 更新入口 => Layer1，指定索引
        // void UpdateLayer1<T>(EReddot current, int layer1Index) where T : IReddotNodeCollectionsLayer1;
        // /// 更新入口 => Layer2
        // void UpdateLayer2<T>(EReddot current) where T : IReddotNodeCollectionsLayer2;
        // /// 更新入口 => Layer2，指定 layer1 索引
        // void UpdateLayer2<T>(EReddot current, int layer1Index) where T : IReddotNodeCollectionsLayer2;
        // /// 更新入口 => Layer2，指定 layer1, layer2 索引
        // void UpdateLayer2<T>(EReddot current, int layer1Index, int layer2Index) where T : IReddotNodeCollectionsLayer2;
    }
    
    public class RedPointTree: IRedPointTree
    {
        /// 依赖型节点检测
        private List<ERedPoint> dependInspect = new List<ERedPoint>();
        /// 处理器映射
        private Dictionary<ERedPoint, IRedPointNode> nodeMap = new Dictionary<ERedPoint, IRedPointNode>();

        public RedPointTree(IRedPointConfig redPointConfig)
        {
        }

        /// 添加组件
        void IRedPointTree.AddComponent(ERedPoint current, IRedPointComponent redPointComponent) => AddComponentBuiltIn(current, redPointComponent);
        private void AddComponentBuiltIn(ERedPoint current, IRedPointComponent redPointComponent)
        {
            if (!nodeMap.TryGetValue(current, out IRedPointNode node))
            {
                nodeMap.Add(current, node = new Common(current));
            }
            node.AddComponent(redPointComponent);
        }

        /// 通用更新
        void IRedPointTree.Update(ERedPoint current) => UpdateBuiltIn(current);
        private void UpdateBuiltIn(ERedPoint current)
        {
            if (!nodeMap.TryGetValue(current, out IRedPointNode node))
            {
                nodeMap.Add(current, node = new Common(current));
            }
            node.Update();
        }
    }
}