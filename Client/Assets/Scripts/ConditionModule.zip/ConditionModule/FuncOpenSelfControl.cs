using UnityEngine;

namespace ConditionModule
{
    [DisallowMultipleComponent]
    public class FuncOpenSelfControl : MonoBehaviour
    {
        [SerializeField] private EFuncOpenId eFuncOpenId;
        private void Awake()
        {
            ConditionManager.Instance.Subscribe(eFuncOpenId.GetCondition(), gameObject.SetActive);
        }
        private void OnDestroy()
        {
            ConditionManager.Instance.Unsubscribe(eFuncOpenId.GetCondition(), gameObject.SetActive);
        }
    }
}