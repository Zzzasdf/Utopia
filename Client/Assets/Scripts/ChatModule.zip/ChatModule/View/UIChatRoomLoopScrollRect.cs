using ChatModule;
using UnityEngine;
using UnityEngine.UI;

// Room 实体
public abstract class ChatRoomEntityBase: MonoBehaviour
{
    
}

public class UIChatRoomLoopScrollRect: ScrollRect
{
    private ChatHouse chatHouse;
        
    
    public void Init(ChatHouse chatHouse)
    {
        
    }

    private void AddMessage()
    {
        
    }
}
