namespace ChatModule
{
    /// Room 可选组件
    public interface IChatRoomUnit
    {
        void Clear();
    }
}