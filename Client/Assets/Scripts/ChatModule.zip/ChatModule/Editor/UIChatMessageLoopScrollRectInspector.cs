using UnityEditor;

namespace ChatModule
{
    [CustomEditor(typeof(UIChatMessageLoopScrollRect))]
    public class UIChatMessageLoopScrollRectInspector : Editor
    {
        // public override void OnInspectorGUI()
        // {
        //     base.OnInspectorGUI();
        // }
    }
}